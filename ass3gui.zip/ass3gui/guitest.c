#include <stdio.h>
#include <stdlib.h>

#include "guicontrol.h"
#include "guicallback.h"

/* CALLBACKS */
void atclose(void);


/* MAIN */
int 
main(int argc, char **argv)
{
    GdkColor color;
    color.red = 65535;
    color.green = 0;
    color.blue = 32000;

    /* Initialize GUI */
    guiInit(&argc, argv);
    guiInitWindow("ass3gui.glade");

    gui_set_move_mode(0);
    gui_set_flip_normals(FALSE);
    gui_set_I_light(color);


    /* Set up exit function */
    atexit(&atclose);

    /* For testing */
    gtk_main();

    /* Together with GLUT, the idle callback is 
       used where a call to guiMainIteration() 
       is made */

    return 0;
}

void 
atclose(void) {
    printf("closing\n");
    /* Buffers, programs and shaders should be deallocated */
}



