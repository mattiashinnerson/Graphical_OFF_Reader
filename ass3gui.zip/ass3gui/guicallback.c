#include "guicallback.h"

GdkColor gui_light_color;
GdkColor gui_ambient_color;

void on_off_chooser_selection_changed(GtkFileChooser *filechooser, gpointer user_data)
{
    gchar* filename = gtk_file_chooser_get_filename(filechooser);
    printf("File chosen: %s\n",filename);
}

void on_flip_normals_toggled(GtkToggleButton *togglebutton, gpointer user_data)
{
    gboolean b = togglebutton->active;
    printf("flip normals: %i\n",b);
}

void on_move_mode_changed(GtkComboBox *combobox, gpointer user_data)
{
    gint index = gtk_combo_box_get_active(combobox);
    printf("Move mode chosen: %d\n", index);
}

void on_light_x_value_changed(GtkSpinButton*spinbutton,gpointer user_data)
{
    gdouble value = gtk_spin_button_get_value(spinbutton);
    printf("Light x: %f\n", value);
}

void on_light_y_value_changed(GtkSpinButton *spinbutton,gpointer user_data)
{
    gdouble value = gtk_spin_button_get_value(spinbutton);
    printf("Light y: %f\n", value);
}

void on_light_z_value_changed(GtkSpinButton*spinbutton, gpointer user_data)
{
    gdouble value = gtk_spin_button_get_value(spinbutton);
    printf("Light z: %f\n", value);
}

gboolean on_I_light_r_value_changing(GtkRange *range, gpointer user_data)
{
    gui_set_color(range, &gui_light_color.red);
    gui_draw_color_shower(gui_light_shower, &gui_light_color);
    gtk_widget_queue_draw(gui_light_shower);

    return FALSE;
}

gboolean on_I_light_g_value_changing(GtkRange *range, gpointer user_data)
{
    gui_set_color(range, &gui_light_color.green);
    gui_draw_color_shower(gui_light_shower, &gui_light_color);
    gtk_widget_queue_draw(gui_light_shower);

    return FALSE;
}

gboolean on_I_light_b_value_changing(GtkRange *range, gpointer user_data)
{
    gui_set_color(range, &gui_light_color.blue);
    gui_draw_color_shower(gui_light_shower, &gui_light_color);
    gtk_widget_queue_draw(gui_light_shower);

    return FALSE;
}

void on_I_light_value_changed(GdkColor color) {
     printf("light source set Irgb=(%i,%i,%i)\n",color.red,color.green,color.blue);
}

void on_I_light_r_value_changed (GtkRange *range, gpointer user_data)
{
    on_I_light_r_value_changing(range, user_data);
    on_I_light_value_changed(gui_light_color);
}

void on_I_light_g_value_changed (GtkRange *range, gpointer user_data)
{
    on_I_light_g_value_changing(range, user_data);
    on_I_light_value_changed(gui_light_color);
}

void on_I_light_b_value_changed (GtkRange *range, gpointer user_data)
{
    on_I_light_b_value_changing(range, user_data);
    on_I_light_value_changed(gui_light_color);
}

gboolean on_I_ambient_r_value_changing(GtkRange *range, gpointer user_data)
{
    gui_set_color(range, &gui_ambient_color.red);
    gui_draw_color_shower(gui_ambient_shower, &gui_ambient_color);
    gtk_widget_queue_draw(gui_ambient_shower);

    return FALSE;
}

gboolean on_I_ambient_g_value_changing(GtkRange *range, gpointer user_data)
{
    gui_set_color(range, &gui_ambient_color.green);
    gui_draw_color_shower(gui_ambient_shower, &gui_ambient_color);
    gtk_widget_queue_draw(gui_ambient_shower);

    return FALSE;
}

gboolean on_I_ambient_b_value_changing(GtkRange *range, gpointer user_data)
{
    gui_set_color(range, &gui_ambient_color.blue);
    gui_draw_color_shower(gui_ambient_shower, &gui_ambient_color);
    gtk_widget_queue_draw(gui_ambient_shower);

    return FALSE;
}

void on_I_ambient_value_changed(GdkColor color) {
     printf("ambient light set Irgb=(%i,%i,%i)\n",color.red,color.green,color.blue);
}

void on_I_ambient_r_value_changed(GtkRange *range, gpointer user_data)
{
    on_I_ambient_r_value_changing(range, user_data);
    on_I_ambient_value_changed(gui_ambient_color);
}

void on_I_ambient_g_value_changed(GtkRange *range, gpointer user_data)
{
    on_I_ambient_g_value_changing(range, user_data);
    on_I_ambient_value_changed(gui_ambient_color);
}

void on_I_ambient_b_value_changed(GtkRange *range, gpointer user_data)
{
    on_I_ambient_b_value_changing(range, user_data);
    on_I_ambient_value_changed(gui_ambient_color);
}

void on_ambient_value_changed(GdkColor color) {
    printf("Ambient color set rgb=(%i,%i,%i)\n",color.red,color.green,color.blue);
}

void on_k_ambient_r_value_changed(GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Ambient kr: %f\n", value);
}

void on_k_ambient_g_value_changed(GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Ambient kg: %f\n", value);
}

void on_k_ambient_b_value_changed(GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Ambient kb: %f\n", value);
}

void on_k_diffuse_r_value_changed(GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Diffuse kr: %f\n", value);
}

void on_k_diffuse_g_value_changed(GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Diffuse kg: %f\n", value);
}

void on_k_diffuse_b_value_changed (GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Diffuse kb: %f\n", value);
}

void on_k_specular_r_value_changed(GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Specular kr: %f\n", value);
}

void on_k_specular_g_value_changed(GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Specular kg: %f\n", value);
}

void on_k_specular_b_value_changed(GtkRange *range, gpointer user_data)
{
    gdouble value = gtk_range_get_value(range);
    printf("Specular kb: %f\n", value);
}

void on_phong_value_changed(GtkSpinButton *spinbutton, gpointer user_data)
{
    gint32 value = (gint32)round(gtk_spin_button_get_value(spinbutton));
    printf("Phong value %i\n", value);
}

void on_win_destroy_event()
{
    printf("Quit\n");
    exit(0);
}

gboolean on_ambient_shower_expose_event(GtkWidget *widget, GdkEventExpose *event, gpointer user_data) 
{
    gui_draw_color_shower(widget, &gui_ambient_color);

    return TRUE;
}

gboolean on_light_shower_expose_event(GtkWidget *widget, GdkEventExpose *event, gpointer user_data)
{
    gui_draw_color_shower(widget, &gui_light_color);

    return TRUE;
}
